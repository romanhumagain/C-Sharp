﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week2_Assignment.Exercise3
{
    public class Test
    {
        public static void Main(string[] args)
        {
            LocalTime london = new LondonTime();
            LocalTime newYork = new NewYorkTime();
            LocalTime tokyo = new TokyoTime();
            LocalTime hongKong = new HongKongTime();

            // Display times for each city
            london.DisplayTimeAndCity();
            newYork.DisplayTimeAndCity();
            tokyo.DisplayTimeAndCity();
            hongKong.DisplayTimeAndCity();
        }
    }
}
