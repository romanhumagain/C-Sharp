﻿using System;

class VolumeCalculation
{
    public double calculateVolume(double radius, double height)
    {
        double volume = Math.PI * radius * radius * height;
        return volume;
    }
}

class Test
{
    static void Main(string[] args)
    {
        // creating an object of class CalculateVolume class
        VolumeCalculation calculaton = new VolumeCalculation();

        Console.Write("Enter the radius of the Cylinder: ");
        double radius = Convert.ToDouble(Console.ReadLine());


        Console.Write("Enter the height of the cylinder: ");
        double height = Convert.ToDouble(Console.ReadLine());


        // Call the method of the class  CalculateVolume
        double volume = calculaton.calculateVolume(radius, height);

        // Displaying the result
        Console.WriteLine($"The volume of the cylinder is: {volume} cubic units");

    }
}